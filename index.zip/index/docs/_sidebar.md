<!-- docs/_sidebar.md --> 

* [首页](/  "网易云升级服务")
* 部署项目
* * [云函数](python/cloud "使用云函数部署")
* * [服务器](python/server "使用云函数部署")
* * [本地使用](python/local "本地部署")
* [部署接口](api/ "API接口的使用")
* * [GitHub](api/github "使用GitHub部署API")
* * [复制服务](api/remix "使用Glitch的remix部署API")
* * [服务器](api/server "使用服务器部署API")
* 效果演示
* * [账号升级](show/up "账号升级页面演示")
* * [微信提醒](show/wechat "微信推送消息")
* * [播放次数](show/count "刷单曲播放次数")
* [项目配置](config/)
* [API接口案例](demo/)
* [接口文档](document/)
* [下载地址](download/)
* [查看日志](log/)
* [注意事项](attention/)
* [常见问题](question/)
* [项目结构](structure/)
* [免责声明](statement/)