# 下载地址 {docsify-ignore-all}



## netease-cloud(升级服务)

项目地址：[https://github.com/ZainCheung/netease-cloud](https://github.com/ZainCheung/netease-cloud)



## netease-cloud-api(API接口)

api接口项目地址：[https://github.com/ZainCheung/netease-cloud-api](https://github.com/ZainCheung/netease-cloud-api)

api的Demo演示地址：[https://netease-cloud-api-sep.glitch.me/](https://netease-cloud-api-sep.glitch.me/)

api的Glitch在线服务器：[https://glitch.com/edit/#!/netease-cloud-api-sep](https://glitch.com/edit/#!/netease-cloud-api-sep)



## netease-cloud-fastplay(快速刷歌)

项目地址：[https://github.com/ZainCheung/netease-cloud-fastplay](https://github.com/ZainCheung/netease-cloud-fastplay)

软件下载地址(蓝奏云)：[https://zaincheung.lanzous.com/i9HD9ehj29g](https://zaincheung.lanzous.com/i9HD9ehj29g)

软件下载地址(天翼云)：https://cloud.189.cn/t/2mERFjiiUj2u (访问码:fd6v)
