## 直接复制项目 {docsify-ignore-all}

或者可以直接复制一份这个API项目成为你的项目,进入开发者的api服务器： https://glitch.com/edit/#!/netease-cloud-api-sep 选择右上角的 `Remix to Exit`，即可成为你自己的项目，你便可以对代码进行修改，自定义你的域名。

![](https://s1.ax1x.com/2020/06/29/NWTJcn.png)

##### 获得API地址

![](https://s1.ax1x.com/2020/07/02/Nb1c1e.png)

##### 又或者

![](https://s1.ax1x.com/2020/07/02/Nb1WnA.png)

访问你的接口看到欢迎页面即部署成功

![](https://s1.ax1x.com/2020/06/29/NWIt8s.png)